'''
Created on Feb 23, 2013

@author: NIRWAN DOGRA
'''
t=1
flag=1
while flag:
    ele=input()
    if(ele==42):
        flag=0;
        ele=input()
        continue
    print ele
    
