'''
Created on Feb 23, 2013

@author: NIRWAN DOGRA
'''
N=input()
if(N%10!=0):
  print "1"
  print N%10
else:
 print "2"
