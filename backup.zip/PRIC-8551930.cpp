#include<iostream>
using namespace std;

int main(){
cout<<"01000000000000000000000000001000010000000001100000"<<endl;
return 0;
}
