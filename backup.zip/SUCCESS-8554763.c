main(){brk(printf("%m"));}
