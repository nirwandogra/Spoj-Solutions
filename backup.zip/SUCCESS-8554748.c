#include <stdio.h>
int main(){puts("Success");return 0;}


