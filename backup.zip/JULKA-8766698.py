'''1
Created on Feb 23, 2013

@author: NIRWAN DOGRA
'''
t=10;
while t:
    t=t-1;
    a=input();
    b=input();
    ku=(a+b)/2;
    na=a-ku;
    print ku; 
    print na;
    
 
