#include<iostream>
#define dd cout<<"HERE"<<endl;
#define gg getch();
#define pi pair<int,int>
#define pii pair<pi,int>
#define ff first
#define ss second
#define ST set<int>
#define VEC vector<int>
#define QU queue<int>
#define MAP map<int ,int>
#define l long
#include<stdio.h>
#define ll long long
#define forr(i,n) for(int i=0;i<n;i++)
#define S(n) scanf("%d",&n);
#define P(n) printf("%d\n",n);
#define C(n) cin>>n;
#define DEBUG if(0)
#define PAUSE system("pause");
#define SET(a,val) memset(a,val,sizeof a);
#define pb push_back
#define CO(n) cout<<n<<endl;
#define MOD 1000000007
using namespace std;
int main()
{
int a[15]={2,
3,
5 ,
8  ,
13  ,
21   ,
34    ,
55     ,
89      ,
144      ,
233       ,
377        ,
610         ,
987          ,
1597}
;
forr(i,15)
{
P(a[i])	
}
return 0;
}         

